public class Humans {
    //author :vrajang shah std#:0008268963
    private int strenghtHumans;
    private int dexterityHumans;
    private  int armourHumans;// all instance varibles for their abilities
    private int moxieHumans;
    private int coinHumans;
    private int healthHumans;
    private int fighter;

//constructors
    public Humans(int strenghtHumans, int dexterityHumans, int armourHumans, int moxieHumans, int coinHumans, int healthHumans, int fighter) {
        super();
        this.strenghtHumans = strenghtHumans;
        this.dexterityHumans = dexterityHumans;
        this.armourHumans = armourHumans;
        this.moxieHumans = moxieHumans;
        this.coinHumans = coinHumans;
        this.healthHumans = healthHumans;
        this.fighter = fighter;
    }

    public Humans(int strenghtHobbit, int dexterityHobbit, int armourHobbit, int moxieHobbit, int coinHobbit, int healthHobbit) {
    }
//getters and setters methods
    public int getStrenghtHumans() {
        return strenghtHumans;
    }

    public void setStrenghtHumans(int strenghtHumans) {
        this.strenghtHumans = strenghtHumans;
    }

    public int getDexterityHumans() {
        return dexterityHumans;
    }

    public void setDexterityHumans(int dexterityHumans) {
        this.dexterityHumans = dexterityHumans;
    }

    public int getArmourHumans() {
        return armourHumans;
    }

    public void setArmourHumans(int armourHumans) {
        this.armourHumans = armourHumans;
    }

    public int getMoxieHumans() {
        return moxieHumans;
    }

    public void setMoxieHumans(int moxieHumans) {
        this.moxieHumans = moxieHumans;
    }

    public int getCoinHumans() {
        return coinHumans;
    }

    public void setCoinHumans(int coinHumans) {
        this.coinHumans = coinHumans;
    }

    public int getHealthHumans() {
        return healthHumans;
    }

    public void setHealthHumans(int healthHumans) {
        this.healthHumans = healthHumans;
    }
    public int getFighter() {
        return fighter;
    }

    public void setFighter(int fighter) {
        this.fighter = fighter;
    }

    @Override
    public String toString() {
        return "Humans{" +
                "strenghtHumans=" + strenghtHumans +
                ", dexterityHumans=" + dexterityHumans +
                ", armourHumans=" + armourHumans +
                ", moxieHumans=" + moxieHumans +
                ", coinHumans=" + coinHumans +
                ", healthHumans=" + healthHumans +
                ", fighter=" + fighter +
                '}';
    }
}
