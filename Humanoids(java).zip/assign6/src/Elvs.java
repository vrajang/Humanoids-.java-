public class Elvs extends Hobbit {
    //author :vrajang shah std#:0008268963

    private int strenghtElvs;
    private int dexterityElvs;
    private  int armourElvs;   // all instance varibles for their abilities
    private int moxieElvs;
    private int coinElvs;
    private int healthElvs;



  
//constructor
    public Elvs(int strenghtElvs, int dexterityElvs, int armourElvs, int moxieElvs, int coinElvs, int healthElvs) {
        super(strenghtElvs,dexterityElvs,armourElvs,moxieElvs,coinElvs,healthElvs);
    }
//geters and setters
    public int getStrenghtElvs() {
        return strenghtElvs;
    }

    public void setStrenghtElvs(int strenghtElvs) {
        this.strenghtElvs = strenghtElvs;
    }

    public int getDexterityElvs() {
        return dexterityElvs;
    }

    public void setDexterityElvs(int dexterityElvs) {
        this.dexterityElvs = dexterityElvs;
    }

    public int getArmourElvs() {
        return armourElvs;
    }

    public void setArmourElvs(int armourElvs) {
        this.armourElvs = armourElvs;
    }

    public int getMoxieElvs() {
        return moxieElvs;
    }

    public void setMoxieElvs(int moxieElvs) {
        this.moxieElvs = moxieElvs;
    }

    public int getCoinElvs() {
        return coinElvs;
    }

    public void setCoinElvs(int coinElvs) {
        this.coinElvs = coinElvs;
    }

    public int getHealthElvs() {
        return healthElvs;
    }

    public void setHealthElvs(int healthElvs) {
        this.healthElvs = healthElvs;
    }

    @Override
    public String toString() {
        return "Elvs{" +
                "strenghtlvs=" + strenghtElvs +
                ", dexterityElvs=" + dexterityElvs +
                ", armourElvs=" + armourElvs +
                ", moxieElvs=" + moxieElvs +
                ", coinElvs=" + coinElvs +
                ", healthElvs=" + healthElvs +
                '}';
    }
}

