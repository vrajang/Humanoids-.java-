public class fakeworld extends Elvs {
    //author :vrajang shah std#:0008268963

    private String elvs; // all the instance variables which are useed in method
    private String hobbits;
    private String humans;
    private int Attackelves;
    private int AttackHobbit;
    private int AttackHumans;
    private int defendelves;
    private int defendHobbit;
    private int defendhumans;
    private int successcore;
    private int wizard;
    private int magicrating;
 //constructor
    public fakeworld(int strenghtElvs, int dexterityElvs, int armourElvs, int moxieElvs, int coinElvs, int healthElvs) {
        super(strenghtElvs, dexterityElvs, armourElvs, moxieElvs, coinElvs, healthElvs);
    }



    public fakeworld(int strenghtElvs, int dexterityElvs, int armourElvs, int moxieElvs, int coinElvs, int healthElvs, int wizard, int magicrating) {
        super(strenghtElvs, dexterityElvs, armourElvs, moxieElvs, coinElvs, healthElvs);
        this.wizard = wizard;
        this.magicrating = magicrating;
    }


//method creating attack
    public void Attack(){

        Attackelves=(getStrenghtElvs()+getDexterityElvs()+getHealthElvs())/3;
        AttackHobbit=(getStrenghtHobbit()+getDexterityHobbit()+getHealthHobbit())/3;
        AttackHumans=2*(getHealthHumans()+getDexterityHumans()+getHealthHumans())/3;


    }
    //method creating defend
    public void defend(int getHealthElvs, int getHealthHobbit, int getHealthHumans){

        getHealthElvs = Attackelves/getArmourElvs();
        getHealthHobbit= AttackHobbit/getArmourHobbit();
        getHealthHumans=AttackHumans/getArmourHumans();


    }
    //method creating stealing
    public int stealing(int getdexterityHobbit){

        successcore=getdexterityHobbit/2;

        return successcore;
    }
    //method creating wizard
    public void  wizard(int getHealthHumans,int magicrating){

        getHealthHumans=getHealthHumans+(magicrating/2);

    }

    @Override
    public String toString() {
        return "fakeworld{" +
                "elvs='" + elvs + '\'' +
                ", hobbits='" + hobbits + '\'' +
                ", humans='" + humans + '\'' +
                ", Attackelves=" + Attackelves +
                ", AttackHobbit=" + AttackHobbit +
                ", AttackHumans=" + AttackHumans +
                ", defendelves=" + defendelves +
                ", defendHobbit=" + defendHobbit +
                ", defendhumans=" + defendhumans +
                ", successcore=" + successcore +
                ", wizard=" + wizard +
                ", magicrating=" + magicrating +
                '}';
    }
}
