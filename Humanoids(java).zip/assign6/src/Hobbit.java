
//author :vrajang shah std#:0008268963
public class Hobbit extends Humans {
    private int strenghtHobbit;
    private int dexterityHobbit;
    private  int armourHobbit;  // all instance varibles for their abilities
    private int moxieHobbit;
    private int coinHobbit;
    private int healthHobbit;
    //constructor

    public Hobbit( int strenghtHobbit, int dexterityHobbit, int armourHobbit, int moxieHobbit, int coinHobbit, int healthHobbit) {
        super(strenghtHobbit,dexterityHobbit,armourHobbit,moxieHobbit,coinHobbit,healthHobbit);



    }

    public Hobbit(int strenghtHumans, int dexterityHumans, int armourHumans, int moxieHumans, int coinHumans, int healthHumans, int fighter) {
        super(strenghtHumans, dexterityHumans, armourHumans, moxieHumans, coinHumans, healthHumans, fighter);
    }

    //geters and setters
    public int getStrenghtHobbit() {
        return strenghtHobbit;
    }

    public void setStrenghtHobbit(int strenghtHobbit) {
        this.strenghtHobbit = strenghtHobbit;
    }

    public int getDexterityHobbit() {
        return dexterityHobbit;
    }

    public void setDexterityHobbit(int dexterityHobbit) {
        this.dexterityHobbit = dexterityHobbit;
    }

    public int getArmourHobbit() {
        return armourHobbit;
    }

    public void setArmourHobbit(int armourHobbit) {
        this.armourHobbit = armourHobbit;
    }

    public int getMoxieHobbit() {
        return moxieHobbit;
    }

    public void setMoxieHobbit(int moxieHobbit) {
        this.moxieHobbit = moxieHobbit;
    }

    public int getCoinHobbit() {
        return coinHobbit;
    }

    public void setCoinHobbit(int coinHobbit) {
        this.coinHobbit = coinHobbit;
    }

    public int getHealthHobbit() {
        return healthHobbit;
    }

    public void setHealthHobbit(int healthHobbit) {
        this.healthHobbit = healthHobbit;
    }

    @Override
    public String toString() {
        return "Hobbit{" +
                "strenghtHobbit=" + strenghtHobbit +
                ", dexterityHobbit=" + dexterityHobbit +
                ", armourHobbit=" + armourHobbit +
                ", moxieHobbit=" + moxieHobbit +
                ", coinHobbit=" + coinHobbit +
                ", healthHobbit=" + healthHobbit +
                '}';
    }
}
