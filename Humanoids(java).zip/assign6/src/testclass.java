import java.util.Scanner;

//author :vrajang shah std#:0008268963

public class testclass {
    String attack;
    String defend; //varibles which are require for user input
    String choice;
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("welcome to the town HOGSFACE "); //screen
        System.out.println(" foons have three kind of humanoids :ELVES | HOBBIT | HUMANS");
        Elvs e1 = new Elvs(5,3,8,5,10,50);//passing values giving their abilities
        Hobbit h1= new Hobbit(10,10,20,50,20,100);
        Humans H1= new Humans(10,10,30,50,20,100,12);
        fakeworld f1 = new fakeworld(10,12,10,15,12,30,40,18);


        System.out.println("do you want to attack or defend?");// asking user for attacking and defending
        String user = keyboard.nextLine();
        System.out.println("Option " + user + " selected!");
        String attack;
        String defend;
        String choice;
        if(user==attack) { //if else condition for attack and defend
            do {
                // Menu for user interface
                System.out.println(
                        "" + "welcome humanoids for attack \n\n" +
                                "there are three humanoids  \n" +

                                "1) Elves\n" +  // asking for humanoids which they want to pick for attack
                                "2) Hobbit\n" +
                                "3) Humans\n" +
                                "4) Quit \n" +

                                "Your Choice: ");

                // read in the user's choice, print it back to them
                choice = keyboard.nextLine();
                System.out.println("Option " + choice + " selected!"); // taking user input for humanoids

                // Carry out users choice
                switch (choice) {

                    case "1":
                        e1.Attack (e1);           //calling methods for attack
                        System.out.println(e1);
                        break;
                    case "2":
                        h1.Attack(h1);
                        System.out.println(m1);
                        break;
                    case "3":
                        H1.Attack(H1);
                        System.out.println(H1);
                    case "4":
                        f1.Attack(f1);
                    }
                    break;

                    case "5":
                        break;
                    default:
                        System.out.println("Invalid choice, choose 1,2,3,4,5");
                        break;
                }
            } while (choice != "5");  // Keep accepting input until the user decides to exit

            System.out.println("Exiting!");
        }
        else(){
        System.out.println(
                "" + "welcome humanoids for defend \n\n" +
                        "there are three humanoids  \n" +

                        "1) Elves\n" +
                        "2) Hobbit\n" +
                        "3) Humans\n" +
                        "4) Quit \n" +

                        "Your Choice: ");

        // read in the user's choice, print it back to them
        choice = keyboard.nextLine();
        System.out.println("Option " + choice + " selected!");//similar like attack asking for defending

        // Carry out users choice
        switch (choice) {

            case "1":
                e1.defend(e1);
                System.out.println(e1);
                break;                    //calls defend method
            case "2":
                h1.defend(h1);
                System.out.println(m1);
                break;
            case "3":
                H1.defend(H1);
                System.out.println(H1);
            case "4":
                f1.Attack(f1);
        }
        break;

        case "5":
            break;
        default:
            System.out.println("Invalid choice, choose 1,2,3,4,5");
            break;

    }     while (choice != "5");  // Keep accepting input until the user decides to exit

            System.out.println("Exiting!");

}











